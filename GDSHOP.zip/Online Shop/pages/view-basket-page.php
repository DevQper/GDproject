<html>
 <?php
 include "templates/head-template.php"
 ?>
 
 <body>

 <?php
 include "templates/nav-template.php"
 ?>

<main>


<section id="basket">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
            <h1>Категории</h1>
<?php include "templates/category-checklist-template.php"?>

            </div>


            <div class="col-md-10 contact-info">
            <h1>Корзина</h1>

        <?php include "templates/basket-table-template.php"?>
        </br>
<?php include "templates/checkout-button-template.php"?>

            </div>
            
        </div>
    </div>
</section>


 </main>

 <?php
 include "templates/footer-template.php"
 ?>
 </body>

 </html>