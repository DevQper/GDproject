<html>
 <?php
 include "templates/head-template.php"
 ?>
 
 <body>

 <?php
 include "templates/nav-template.php"
 ?>

<main>


<section id="products">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
            <h1>Заказы</h1>
<?php include "templates/all-orders-totals-template.php"?>
<h2>Покупатели</h2>
<?php include "templates/customer-checklist-template.php"?>
            </div>


            <div class="col-md-10 contact-info">
            <h1>Заказы</h1>    
        <?php include "templates/editable-orders-template.php" ?>

            </div>
            
        </div>
    </div>
</section>


 </main>

 <?php
 include "templates/footer-template.php"
 ?>
 </body>

 </html>
