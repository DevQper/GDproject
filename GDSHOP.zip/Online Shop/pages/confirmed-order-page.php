<html>
 <?php
 include "templates/head-template.php"
 ?>
 
 <body>

 <?php
 include "templates/nav-template.php"
 ?>

<main>
<section id="order-details">

<?php include "templates/confirm-order-template.php"?>



</section>

 </main>

 <?php
 include "templates/footer-template.php"
 ?>
 </body>

 </html>