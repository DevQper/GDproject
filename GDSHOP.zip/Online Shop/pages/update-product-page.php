<html>
 <?php
 include "templates/head-template.php"
 ?>
 
 <body>

 <?php
 include "templates/nav-template.php"
 ?>

<main>
<section id="update-product">

<?php include "templates/update-product-template.php"?>



</section>

 </main>

 <?php
 include "templates/footer-template.php"
 ?>
 </body>

 </html>