<html>
 <?php
 include "templates/head-template.php"
 ?>
 
 <body>

 <?php
 include "templates/nav-template.php"
 ?>

<main>
<section id="orders">

<?php include "templates/update-order-template.php"?>



</section>

 </main>

 <?php
 include "templates/footer-template.php"
 ?>
 </body>

 </html>