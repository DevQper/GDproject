<html>
 <?php
 include "templates/head-template.php"
 ?>
 
 <body>

 <?php
 include "templates/nav-template.php"
 ?>

<main>


<section id="products">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
            <h1>Категории</h1>
<?php include "templates/category-checklist-template.php"?>
            </div>


            <div class="col-md-10 contact-info">
            <h1>Товары</h1>
        <p class ="text-center" >Важно!!! Вы можете удалить товар только в том случае, если удалили все заказы в которых этот товар присутствовал.</p>

    <a href="insert-product.php" class="btn btn-primary">Добавить новый продукт</a>
    <br/><br/>
    
        <?php include "templates/editable-products-template.php" ?>

            </div>
            
        </div>
    </div>
</section>


 </main>

 <?php
 include "templates/footer-template.php"
 ?>
 </body>

 </html>





