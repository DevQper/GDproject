<!DOCTYPE html>
<html>
<?php include "templates/head-template.php"?>
<body>
<?php include "templates/nav-template.php"?>


        <!----------------slider-------------->
        <div id="slider"> 
            <div id="headerSlider" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">    
                  <li data-target="#headerSlider" data-slide-to="0" class="active"></li>
                  <li data-target="#headerSlider" data-slide-to="1"></li>
                  <li data-target="#headerSlider" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="img/banner-1.jpg" class="d-block img-fluid">
                    <div class="carousel-caption">
                         <h5>WORK IN COMPUTER SCIENCE</h5>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="img/banner-2.jpg" class="d-block img-fluid">
                    <div class="carousel-caption">
                        <h5>GROW WITH COMPUTER SCIENCE</h5>
                   </div>
                  </div>
                  <div class="carousel-item">
                    <img src="img/banner-3.jpg" class="d-block img-fluid">
                    <div class="carousel-caption">
                        <h5>ENJOY COMPUTER SCIENCE</h5>
                   </div>
                  </div>
                </div>
                <a class="carousel-control-prev" href="#headerSlider" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#headerSlider" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
        </div>

        <!----------------ABOUT SECTION-------------->
<section id="about">
 <div class="container">
     <div class="row">
         <div class="col-md-6">
             <h2>About Us</h2>
             <div class="about-content">
                Techno Products KZ was started by IT teachers and students at Nazarbayev Intellectual Schools - Petropavlovsk.

                We were all frustrated in general by the lack of affordable computer parts from a store with good customer service in Petropavlovsk, so we decided to start our own!!
                
                We were all working on Grade 12 web-programming projects when we had the idea, so the timing was perfect! We could use our newly learned skills from our project work to start a truly local and customer-driven business with afffordable products.
                
                As the years have passed, our business has continued to grow in strength. We believe that this is because we place customer satisfaction above trying to make as much profit as possible! Our customers will always be our top priority.
             </div>
             <button type="button" class="btn btn-primary">Read more</button>
         </div>
         <div class="col-md-6 skills-bar">
                <p>Adobe Photoshop</p>
                <div class="progress">
                <div class="progress-bar" style="width:80%;">80%</div>
                </div>
                <p>HTML</p>
                <div class="progress">
                <div class="progress-bar" style="width:85%;">85%</div>
                </div>
                <p>CSS</p>
                <div class="progress">
                <div class="progress-bar" style="width:75%;">75%</div>
                </div>
                <p>bootstrap</p>
                <div class="progress">
                <div class="progress-bar" style="width:50%;">50%</div>
                </div>
         </div>
     </div>
 </div>
</section>

<!-------Services---------->
<section id="services">
    <div class="container">
        <h1>Our Services</h1>
        <div class="row services">
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-desktop"></i>
                </div>
                <h3>Web Development</h3>
                <p>We build leading destinations for buying, selling, and exchanging products and services, spanning across 5 continents and used by 350 million people every month.</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-tablet"></i>
                </div>
                <h3>App Development</h3>
                <p>We build leading destinations for buying, selling, and exchanging products and services, spanning across 5 continents and used by 350 million people every month.</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-line-chart"></i>
                </div>
                <h3>Digital Marketing</h3>
                <p>We build leading destinations for buying, selling, and exchanging products and services, spanning across 5 continents and used by 350 million people every month.</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-paint-brush"></i>
                </div>
                <h3>Graphics Design</h3>
                <p>We build leading destinations for buying, selling, and exchanging products and services, spanning across 5 continents and used by 350 million people every month.</p>
            </div> 
        </div>
    </div>
     
</section>


<!--------------TEAM MEMBERS SECTION--------------->
<section id="team">
    <div class="container">
        <h1>Our team</h1>
        <div class="row">
            <div class="col-md-3 profile-pic text-center">
                <div class="img-box">
                    <img src="img/team1.jpg" class="img-responsive">
                    <ul>
                    <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                    <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                    <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </div>
                <h2>Sigmund Freud</h2>
            <h3>Founder / CEO</h3>
            <p>Sigmund Freud - was an Austrian neurologist and the founder of psychoanalysis, a clinical method for treating psychopathology through dialogue between a patient and a psychoanalyst</p>
            </div>

            <div class="col-md-3 profile-pic text-center">
                <div class="img-box">
                    <img src="img/team2.jpg" class="img-responsive">
                    <ul>
                    <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                    <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                    <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </div>
                <h2>Sigmund Freud</h2>
            <h3>Founder / CEO</h3>
            <p>Sigmund Freud - was an Austrian neurologist and the founder of psychoanalysis, a clinical method for treating psychopathology through dialogue between a patient and a psychoanalyst</p>
            </div>

            <div class="col-md-3 profile-pic text-center">
                <div class="img-box">
                    <img src="img/team3.jpg" class="img-responsive">
                    <ul>
                    <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                    <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                    <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </div>
                <h2>Sigmund Freud</h2>
            <h3>Founder / CEO</h3>
            <p>Sigmund Freud - was an Austrian neurologist and the founder of psychoanalysis, a clinical method for treating psychopathology through dialogue between a patient and a psychoanalyst</p>
            </div>

            <div class="col-md-3 profile-pic text-center">
                <div class="img-box">
                    <img src="img/team4.jpg" class="img-responsive">
                    <ul>
                    <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                    <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                    <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </div>
                <h2>Sigmund Freud</h2>
            <h3>Founder / CEO</h3>
            <p>Sigmund Freud - was an Austrian neurologist and the founder of psychoanalysis, a clinical method for treating psychopathology through dialogue between a patient and a psychoanalyst</p>
            </div>
            
        </div>
    </div>


</section>
<!--------------THE END OF TEAM MEMBERS SECTION--------------->


<!-----------------------PROMO SECTION------------------------>

<section id="promo">
    <div class="container">
        <p>Get Free Domain Name and Web Hosting</p>
        <a href="#contact" class="btn btn-primary">Contact Us</a>
    </div>
</section>

<!-----------------THE END OF PROMO SECTION------------------->





<!---------------------------TESTIMONIALS------------------------------>

<section id="testimonials">
    <div class="container">
        <h1>Testimonials</h1>
        <p class ="text-center" >Watch more my works on the web</p>
        <div class="row">
            <div class="col-md-4 text-center" >
              <div class="profile">
                  <img src="img/user1.jpg" class="user">
                  <blockquote>Techno Products KZ was started by IT teachers and students at Nazarbayev Intellectual Schools - Petropavlovsk.</blockquote>
                    <h3>Stephan Nolan <span>Co-Founder at NIS</span></h3>
              </div>
            </div>

            <div class="col-md-4 text-center" >
                <div class="profile">
                    <img src="img/user2.jpg" class="user">
                    <blockquote>Techno Products KZ was started by IT teachers and students at Nazarbayev Intellectual Schools - Petropavlovsk.</blockquote>
                      <h3>Dias Koshan <span>Colorful representative of the team</span></h3>
                </div>
              </div>

              <div class="col-md-4 text-center" >
                <div class="profile">
                    <img src="img/user3.jpg" class="user">
                    <blockquote>Techno Products KZ was started by IT teachers and students at Nazarbayev Intellectual Schools - Petropavlovsk.</blockquote>
                      <h3>Almaz Topaz <span>The asset of the team, that value a lot</span></h3>
                </div>
              </div>

              <div class="col-md-4 text-center" >
                <div class="profile">
                    <img src="img/user4.jpg" class="user">
                    <blockquote>Techno Products KZ was started by IT teachers and students at Nazarbayev Intellectual Schools - Petropavlovsk.</blockquote>
                      <h3>Who Knows <span>We dont know who it is</span></h3>
                </div>
              </div>

              <div class="col-md-4 text-center" >
                <div class="profile">
                    <img src="img/user5.jpg" class="user">
                    <blockquote>Techno Products KZ was started by IT teachers and students at Nazarbayev Intellectual Schools - Petropavlovsk.</blockquote>
                      <h3>Great Girl <span>You know what we are doing</span></h3>
                </div>
              </div>
        </div>

    </div>
</section>


<!---------------------------GET IN TOUCH SECTION----------------------------->

<section id="contact">
    <div class="container">
        <h1>Get In Touch</h1>
        <div class="row">
            <div class="col-md-6">
                <form class="contact-form" action="">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your Name" name="" id="">
                    </div>


                    <div class="form-group">
                        <input type="number" class="form-control" placeholder="Phone Number" name="" id="">
                    </div>


                    <div class="form-group">
                        <input type="email" class="form-control" placeholder="Email Adress" name="" id="">
                    </div>


                    <div class="form-group">
                        <textarea class="form-control" rows="4" placeholder="Your Message" name="" id=""></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">SEND MESSAGE</button>

                </form>
            </div>


            <div class="col-md-6 contact-info">
                <div class="follow"><b>Address</b> <i class="fa fa-map-marker"></i> Shymkent zhol, Petropavlovsk, KZ </div>
                
         
                <div class="follow"><b>Phone</b> <i class="fa fa-phone"></i> +7 777 77 7777, +7 705 70 5777 </div>
                
            
                <div class="follow"><b>Email</b> <i class="fa fa-envelope-o"></i> Detsel7777@gmail.com </div>
                
                
                <div class="follow"><label><b>Get Social</b></label> 
                    <a href="#"><i class="fa fa-facebook"></i></a> 
                    <a href="#"><i class="fa fa-linkedin"></i></a>
                    <a href="#"><i class="fa fa-youtube"></i></a>
                    <a href="#"><i class="fa fa-google-plus"></i></a>
                </div>
            </div>
            
        </div>
    </div>
</section>

<!-------------------------------THE END OF GET IN TOUCH SECTION----------------------------->
<?php include "templates/footer-template.php"?>



<script src="js/smooth-scroll.js"></script>     
<script>
	var scroll = new SmoothScroll('a[href*="#"]');
</script>

</body>
</html> 