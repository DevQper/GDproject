<html>
 <?php
 include "templates/head-template.php"
 ?>
 
 <body>

 <?php
 include "templates/nav-template.php"
 ?>

<main>


<section id="products">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
            <h1>Категории</h1>
<?php include "templates/category-checklist-template.php"?>
            </div>


            <div class="col-md-10 contact-info">
            <h1>Товары</h1>

        <?php include "templates/products-table-template.php" ?>

            </div>
            
        </div>
    </div>
</section>


 </main>

 <?php
 include "templates/footer-template.php"
 ?>
 </body>

 </html>

