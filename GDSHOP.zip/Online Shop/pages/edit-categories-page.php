<html>
 <?php
 include "templates/head-template.php"
 ?>
 
 <body>

 <?php
 include "templates/nav-template.php"
 ?>

<main>
<section id="categories">
<div class="container">


<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center mb-5">Добавить категорию</h2>
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="card border-secondary">
                        <div class="card-header">
                            <h3 class="mb-0 my-2">Введите данные категории</h3>
                        </div>
                        <div class="card-body">
                        <form action="insert-category-submit.php" method="post">
                        <div class="form-group">
                            <label for="Category">Название категории</label>
                            <input type="text" class="form-control" id="Category" name="Category" value="" placeholder="Введите название категории" required="">
                        </div>
                        <button type="submit" class="btn btn-primary">Ввести</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
            <!--/row-->

        </div>
        <!--/col-->
    </div>
    <!--/row-->
</div>
<!--/container-->

        <h1>Категории</h1>
        <p class ="text-center" >Внимание, удаление категрии приведет к удалению всех товаров внутри нее!</p>
        <?php include "templates/editable-categories-template.php"?>    
    
    
    </div>




</section>

 </main>

 <?php
 include "templates/footer-template.php"
 ?>
 </body>

 </html>