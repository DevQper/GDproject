<?php
require "includes/authorisation-admin.php";

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

require_once "models/Orders.php";

if(!empty($_GET["orderid"]))
{
       // delete the products in an order
    deleteOrderProducts($_GET["orderid"]);

    deleteOrder($_GET["orderid"]);

}

redirect("edit-orders.php", false);

?>