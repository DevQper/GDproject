<?php
require "includes/authorisation-admin.php";

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

if(!empty($_GET["productid"]))
{

    include "pages/update-product-page.php";
}


?>