<?php
require_once "models/Users.php";

$resultArr = getLoggedInUser();
 
if($resultArr):
?>
<?php echo substr($row["Firstname"], 0, 1); ?>. <?php echo $row["Surname"]; ?>
<br/>
<?php echo $row["Street"]; ?> <?php echo $row["ApartmentNumber"]; ?>
<br/>
<?php echo $row["City"]; ?> <?php echo $row["Postcode"]; ?>, <?php echo $row["Region"]; ?>
<br/>
<?php echo $row["Country"]; ?>
<br/>
<br/>
<?php 
endif;
?>

