<?php 
 require_once "models/Users.php";

 $resultArr = getLoggedInUser();

 if($resultArr && !empty($resultArr[0])):
    $row = $resultArr[0];
?>
<p>
Дорогой <?php echo substr($row["Firstname"], 0, 1); ?>. <?php echo $row["Surname"]; ?>
</p>
<?php 
endif;
?>