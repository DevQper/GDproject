<?php 
require_once "models/Products.php";
require_once "models/Categories.php";   

if(!empty($_GET["productid"])):
    
  $resultArrCategories = getCategories();
  $resultArrProduct = getProduct($_GET['productid']);

    if($resultArrProduct && !empty($resultArrProduct[0]) && $resultArrCategories):
        $rowProduct = $resultArrProduct[0];



?>

<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center mb-5">Изменить категорию</h2>
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="card border-secondary">
                        <div class="card-header">
                               <h3 class="mb-0 my-2">Введите новые данные категории</h3>
                              </div>
                                       <div class="card-body">
                                        <form action="update-product-submit.php" method="post" enctype ="multipart/form-data" class="input-form"> 
                                         <div class="form-group">
                                             <input type="hidden" class="form-control" name="ProductID" value="<?php echo $rowProduct["ProductID"]; ?>">
                                          </div>
                                         <div class="form-group">
                                          <label for="Product">Название продукции</label>
                                          <br/>
                                           <input type="text" class="form-control" name="Product" value="<?php echo $rowProduct["Product"]; ?>" required>
                                           </div>
                                           <br/>
                                           <br/>
                                           <div class="form-group">
                                          <label for="Cost">Цена </label>
                                          <br/>
                                           <input type="number" class="form-control" step="any" min="0" name="Cost" value="<?php echo $rowProduct["Cost"]; ?>" required>
                                           </div>
                                           <br/>
                                           <br/>
                                           <div class="form-group">
                                          <label for="Price">Цена продажи </label>
                                          <br/>
                                           <input type="number" class="form-control" step="any" min="0" name="Price" value="<?php echo $rowProduct["Price"]; ?>" required>
                                           </div>
                                           <br/>
                                           <br/>
                                           <div class="form-group">
                                          <label for="Quantity">Количество</label>
                                          <br/>
                                           <input type="number" class="form-control" step="1" min="0" name="Quantity" value="<?php echo $rowProduct["Quantity"]; ?>" required>
                                           </div>
                                           <br/>
                                           <br/>
                                           <div class="form-group">Фото товара 300х300</label>
                                           <br/>
                                           <td><?php echo "<img src='data:image/jpeg;base64," . base64_encode ($rowProduct["Picture"]) . "' class='product-image'/>"; ?></td>
                                           <br/>
                                           <input type="file" name="Picture">
                                           <br/>
                                           <br/>
                                           <div class="form-group">
                                          <label for="Quantity">Категория</label>
                                           <br/>
                                           <select name="CategoryID" required>
                                          <?php
                                           foreach ($resultArrCategories as $rowCategory):
                                            ?>
                                           <option <?php echo $rowProduct["CategoryID"]==$rowCategory["CategoryID"] ? "selected": ""; ?> value ="<?php echo $rowCategory["CategoryID"]; ?>"?><?php echo $rowCategory["Category"]; ?></option>
                                          <?php
                                           endforeach;
                                           ?>
                                           </select>
                                           <br/>
                                           <br/>
                                           </div>

                                           </div>
                                           
                                                   <button type="submit" class="btn btn-primary">Ввести</button>
                                        </form>
                                                </div> 
                                          </div>
                                 </div>
                         </div>
                     </div>
                 </div>
            <!--/row-->

             </div>
        <!--/col-->
         </div>
    <!--/row-->
     </div>
<!--/container-->

<?php 
endif;
endif;
?>