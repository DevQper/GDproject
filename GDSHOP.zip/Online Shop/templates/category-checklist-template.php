<?php 

require_once "models/Categories.php";

$resultArr = getCategories();

if($resultArr):
    foreach($resultArr as $row):

?>

    <div id="categories">
        
    <div class="btn-group-toggle" data-toggle="buttons">
  <label for='<?php echo $row["CategoryID"]; ?>' class="btn btn-outline-warning active">
    <input type="checkbox" class='category' name='<?php echo $row["CategoryID"]; ?>' id='<?php echo $row["CategoryID"]; ?>' onchange='showHideRows(this)'checked/><?php echo $row["Category"]; ?>
  </label>
</div>
<br/>
    </div>
    <?php endforeach;
    endif;
    ?>

