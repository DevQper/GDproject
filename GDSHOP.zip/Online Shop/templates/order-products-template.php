<?php 
require_once "models/Orders.php";

$orderid = getLoggedInUserLastOrderID();
$resultArr = getOrdersProducts($orderid);

if($resultArr):
?>

<div id='Products'>
<table class="table">
<thead>
<tr>
<th scope="col">Товар</th>
<th scope="col">Количество</th>
<th scope="col">Цена</th>
<th scope="col">Сумма</th>
</tr>

<?php 
foreach($resultArr as $row):
    ?>
    <tr id='<?php echo $row["ProductID"] ?>' class='Category <?php $row["ProductID"]; ?>'>
    <td><?php echo $row["Product"] ?></td>
    <td><?php echo $row["Quantity"] ?></td>
    <td><?php echo $row["Price"] ?></td>
    <td><?php echo $row["TotalPrice"] ?></td>
    <td>
    </tr>
    <?php 
    endforeach;
    ?>
    </table>
    </div>

    <?php 
    endif 
    ?>