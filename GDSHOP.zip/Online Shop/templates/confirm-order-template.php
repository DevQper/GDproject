<?php include "templates/user-greeting-template.php"?>
<p> Благодарим за ваш заказ. Подтвердите его внизу!</p>

<h4>Delivery Details</h4>
<?php include "templates/user-delivery-details-template.php" ?>
<?php include "templates/order-products-template.php" ?>
<?php include "templates/order-totals-template.php" ?>
