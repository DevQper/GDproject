<?php
if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "models/Products.php";

$resultArr = getBasketProducts();

if($resultArr):
?>

<div id='basket'>
<table class="table">
<thead>
<tr>
<th scope="col">Товар</th>
<th scope="col">Цена</th>
<th scope="col">Категория</th>
<th scope="col">Количество</th>
<th scope="col">Фото</th>
<th></th>
</tr>

<?php 
foreach($resultArr as $row):
    ?>
<tbody>
    <tr id='<?php echo $row["ProductID"] ?>' class='Row <?php $row["CategoryID]"] ?>'>
    <td><?php echo $row["Product"] ?></td>
    <td><?php echo $row["Price"] ?></td>
    <td><?php echo $row["Category"] ?></td>
    <td>
    <?php 
    if(!empty($_SESSION['basket']))
    {
        echo count(array_keys($_SESSION['basket'], $row["ProductID"]));
    }
?>
</td>
<td><?php echo "<img src='data:image/jpeg;base64," . base64_encode($row["Picture"]) ."' class='product-image'/>"; ?></td>
<td>
<button class="btn btn-danger" onclick='removeFromBasket(<?php echo $row["ProductID"] ?>)'>Удалить из корзины</button>
<button class="btn btn-danger" onclick='addToBasket(<?php echo $row["ProductID"] ?>)'>Добавить в корзину</button>
</td>
</tbody>
</tr>
</thead>
<?php endforeach; ?>
</table>
</div>

     <?php endif; ?>