<!-------------------------------FOOTER----------------------------->

<section id="footer">
    <div class="container text-center">
        <p>Made with <i class="fa fa-heart-o"></i> by NIS CS Lovers</p>
    </div>
</section>
<!-------------------------------THE END OF FOOTER----------------------------->