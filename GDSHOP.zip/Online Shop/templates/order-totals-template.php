<?php 
require_once "models/Orders.php";

$orderid = getLoggedInUserLastOrderID();
$resultArr = getOrderTotals($orderid);

if($resultArr && !empty($resultArr[0])):
    $row = $resultArr[0];
?>

<p><strong>Без НДС:</strong> <?php echo $row["BeforeTaxPrice"]; ?></p>
<p><strong>НДС:</strong> <?php echo $row["Tax"]; ?></p>
<p><strong>Сумма</strong> <?php echo $row["TotalPrice"]; ?></p>

<?php 
endif;
?>