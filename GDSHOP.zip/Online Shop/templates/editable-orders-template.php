<?php 

require_once "models/Orders.php";

$resultArr = getOrdersDetails();

if($resultArr):
?>

<div id="sales">
<table class="table">
    <tr>
      <th scope="col">Дата</th>
      <th scope="col">Оплачено?</th>
      <th scope="col">Имя покупателя</th>
      <th scope="col">Cумма заказа</th>
      <th scope="col">Выручка</th>
      <th scope="col"></th>
    </tr>

    <?php
     foreach($resultArr as $row):
    ?>
    <tr id='<?php echo $row["UserID"]; ?>' class='Row <?php echo $row["UserID"]; ?>'>
      <td><?php echo $row["Date"]; ?></td>
      <td><?php echo $row["Paid"] ? "Yes" : "No"; ?></td>
      <td><?php echo $row["CustomerName"]; ?></td>
      <td><?php echo $row["SaleAmount"]; ?></td>
      <td><?php echo $row["Profit"]; ?></td>
      <td>
      <a href="update-order.php?orderid=<?php echo $row["OrderID"]; ?>" class="btn btn-success"><i class="fa fa-edit"></i></a>
      <a href="delete-order.php?orderid=<?php echo $row["OrderID"]; ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
      <a href="view-products.php?orderid=<?php echo $row["OrderID"]; ?>" class="btn btn-warning"><i class="fa fa-eye"></i></a>
      </td>
    </tr>
     <?php endforeach; ?>
</table>
</div>

     <?php endif; ?>