<?php
require_once "models/Orders.php";

$resultArr = getAllOrdersTotals();

if($resultArr && !empty($resultArr[0])):
    $row = $resultArr[0];
?>

<p><strong>Общая цена:</strong> <?php echo $row["TotalCost"]; ?></p>
<p><strong>Общая сумма продаж:</strong> <?php echo $row["TotalSales"]; ?></p>
<p><strong>Общая выручка:</strong> <?php echo $row["TotalProfit"]; ?></p>

<?php 
endif;
?>