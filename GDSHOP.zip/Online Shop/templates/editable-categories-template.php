<?php

require_once "models/Categories.php";

$resultArr = getCategories();

if($resultArr):

?>

<div class="container">
  <div class="row">
    <div class="col-6">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Категория</th>
          </tr>


          <?php 
 foreach($resultArr as $row):
?>

        </thead>
        <tbody>
          <tr id="<?php echo $row["CategoryID"]; ?>" class="Row <?php echo $row["CategoryID"] ?>">
            <td><?php echo $row["Category"]; ?></td>
            <td>
            <a href="update-category.php?categoryid=<?php echo $row["CategoryID"]; ?>" class="btn btn-success"><i class="fa fa-edit"></i></a>
            <a href="delete-category.php?categoryid=<?php echo $row["CategoryID"]; ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
            </td>
            <?php
endforeach; 
?>

        </tbody>
      </table>
    </div>

    <div class="col-6">
    <div class="img-box">
                    <img src="img/Template1.jpg" class="img-responsive">
     </div>

</div>
</div>

<?php 
endif 
?>








<div class="col-6">
     
    </div>