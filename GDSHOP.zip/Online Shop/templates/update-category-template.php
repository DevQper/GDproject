<?php 
require_once "models/Categories.php";

if(!empty($_GET["categoryid"])):
    $resultArr = getCategory($_GET["categoryid"]);

    if($resultArr && !empty($resultArr[0])):
        $row = $resultArr[0];



?>

<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center mb-5">Изменить категорию</h2>
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="card border-secondary">
                        <div class="card-header">
                               <h3 class="mb-0 my-2">Введите новые данные категории</h3>
                              </div>
                                       <div class="card-body">
                                                       <form action="update-category-submit.php" method="post">
                                         <div class="form-group">
                                             <input type="hidden" class="form-control" id="CategoryID" name="CategoryID" value="<?php echo $row["CategoryID"]; ?>">
                                          </div>
                                         <div class="form-group">
                                          <label for="Сategory">Название категории</label>
                                           <input type="text" class="form-control" id="Category" name="Category" value="<?php echo $row["Category"]; ?>" required>
                                           </div>
                                                   <button type="submit" class="btn btn-primary">Submit</button>
                                                      </form>
                                                </div> 
                                          </div>
                                 </div>
                         </div>
                     </div>
                 </div>
            <!--/row-->

             </div>
        <!--/col-->
         </div>
    <!--/row-->
     </div>
<!--/container-->

<?php 
endif;
endif;
?>