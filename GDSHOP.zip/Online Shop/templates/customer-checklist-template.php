<?php 
require_once "models/Users.php";

$resultArr = getUsers();

if($resultArr):
    foreach($resultArr as $row):
?>
<div id='users'>
<input type="checkbox" class='users' name='<?php echo $row["UserID"]; ?>' id='<?php echo $row["UserID"]; ?>' onchange='showHideRows(this)'checked/>
<label for = '<?php echo $row["UserID"] ?>'><?php echo $row["Firstname"] . " " . $row["Surname"]; ?></label>
<br/>
</div>
<?php 
endforeach;
endif;
?>