
<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center mb-5">Регистрация</h2>
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="card border-secondary">
                        <div class="card-header">
                            <h3 class="mb-0 my-2">Введите свои данные</h3>
                        </div>
                        <div class="card-body">
                            <form action="register-submit.php" onsubmit="return submitRegistration()" method="post" class="input-form" role="form" autocomplete="off">
                                <div class="form-group">
                                    <label for="EmailAddress">Почта</label>
                                    <input type="email" class="form-control" id="EmailAddress" placeholder="Почта" name="EmailAddress"   required="" >
                                </div>
                                <div class="form-group">
                                    <label for="MobileNumber">Номер телефона</label>
                                    <input type="tel" class="form-control" id="MobileNumber" placeholder="Номер телефона" name="MobileNumber" required="" >
                                </div>
                                <div class="form-group">
                                    <label for="Titel">Название Компании</label>
                                    <input type="text" class="form-control" id="Titel" placeholder="Название Компании" name="Titel" required="" >
                                </div>
                                <div class="form-group">
                                    <label for="Firstname">Имя</label>
                                    <input type="text" class="form-control" id="Firstname" placeholder="Имя" name="Firstname" required="" >
                                </div>
                                <div class="form-group">
                                    <label for="Surname">Фамилия</label>
                                    <input type="text" class="form-control" id="Surname" placeholder="Фамилия" name="Surname" required="" >
                                </div>
                                <div class="form-group">
                                    <label for="ApartmentNumber">Номер дома</label>
                                    <input type="text" class="form-control" id="ApartmentNumber" placeholder="Номер дома" name="ApartmentNumber" required="">
                                </div>
                                <div class="form-group">
                                    <label for="Street">Улица</label>
                                    <input type="text" class="form-control" id="Street" placeholder="Улица" name="Street" required="" >
                                </div>
                                <div class="form-group">
                                    <label for="City">Город</label>
                                    <input type="text" class="form-control" id="City" placeholder="Город" name="City" required="">
                                </div>
                                <div class="form-group">
                                    <label for="Region">Регион</label>
                                    <input type="text" class="form-control" id="Region" placeholder="Регион" name="Region" required="" >
                                </div>
                                <div class="form-group">
                                    <label for="Postcode">Почтовый Индекс</label>
                                    <input type="text" class="form-control" id="Postcode" placeholder="Почтовый Индекс" name="Postcode" required="" >
                                </div>
                                <div class="form-group">
                                    <label for="Country">Страна</label>
                                    <input type="text" class="form-control" id="Country" placeholder="Страна" name="Country" required="" >
                                </div>
                                <div class="form-group">
                                    <label for="RegistrationPassword">Пароль</label>
                                    <input type="password" class="form-control" id="RegistrationPassword" placeholder="Пароль" title="At least 6 characters with letters and numbers" name="RegistrationPassword" required="">
                                </div>
                                <div class="form-group">
                                    <label for="ConfirmRegistrationPassword">Подтвердите пароль</label>
                                    <input type="password" class="form-control" id="ConfirmRegistrationPassword" placeholder="Пароль (повторно)" name="ConfirmRegistrationPassword" required="">
                                </div>
                                <div class="form-group">
                                    <button type="submit" value="Submit" class="btn btn-success btn-lg float-right">Зарегистрироваться</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!--/row-->

        </div>
        <!--/col-->
    </div>
    <!--/row-->
</div>
<!--/container-->