<?php 
if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "models/Users.php";?>

<section id="nav-bar"> 
        <nav class="navbar navbar-expand-lg navbar-light">

<?php 

if(!isAUserLoggedIn()):

?>

<!------------------------------navigationBar----------------------->

            <a class="navbar-brand" href="#"><img src="img/logo.png"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                      <a class="nav-link" href="index.php">Главная</a>
                      </li>
                     <li class="nav-item">
                     <a class="nav-link" href="#about">О Нас</a>
                       </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#services">Сервисы</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="#team">Наша Команда</a>
                    </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#testimonials">Отзывы</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#contact">Связь с нами</a>
                  </li>                  
                 </ul>
                 <ul class="nav navbar-nav flex-row justify-content-between ml-auto">
                <li class="nav-item order-2 order-md-1"><a href="#" class="nav-link" title="settings"><i class="fa fa-cog fa-fw fa-lg"></i></a></li>
                <li class="dropdown order-1">
                    <button type="button" id="dropdownMenu1" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">Войти <span class="caret"></span></button>
                    <ul class="dropdown-menu dropdown-menu-right mt-2">
                       <li class="px-3 py-2">
                           <form action="login-submit.php" method="post" class="login-form">
                                <div class="form-group">
                                    <input name="EmailAddress" id="EmailAddress" placeholder="Email" class="form-control form-control-sm" type="text"  required="">
                                </div>
                                <div class="form-group">
                                    <input name="Password" id="Password" placeholder="Password" class="form-control form-control-sm" type="text" required="">
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary btn-block" valuse="login">
                                </div>
                                <div class="form-group text-center">
                                    <small><a href="register.php">Зарегистрироваться</a></small>
                                </div>
                            </form>
                        </li>
                    </ul>
            </div>
<?php   

elseif(getUsersRole()=="user"):


?>

<!------------------------------navigationBar Of the ordinary user------------------->
            <a class="navbar-brand" href="#"><img src="img/logo.png"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                      <a class="nav-link" href="index.php">Главная</a>
                      </li>
                     <li class="nav-item">
                     <a class="nav-link" href="view-products.php">Товары</a>
                       </li>
                    <li class="nav-item">
                      <a class="nav-link" href="view-basket.php">Корзина</a>
                    </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#contact">Связь с нами</a>
                  </li>                  
                 </ul>
                 <ul class="nav navbar-nav flex-row justify-content-between ml-auto">
                <li class="nav-item order-2 order-md-1"><a href="#" class="nav-link" title="settings"><i class="fa fa-cog fa-fw fa-lg"></i></a></li>
                <li class="dropdown order-1">
                    <button type="button" id="dropdownMenu1" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">Мой профиль<span class="caret"></span></button>
                    <ul class="dropdown-menu dropdown-menu-right mt-2">
                       <li class="px-3 py-2">
                           <form class="form" role="form">
                                <div class="form-group">
                                    <?php
                                    echo $_SESSION["firstname"] . " " . $_SESSION["surname"];
                                    ?>
                                </div>
                                <div class="form-group">
                                    
                                </div>
                                <div class="form-group">
                                    <a href="logout.php" type="submit" class="btn btn-primary btn-block">Выйти</a>
                                </div>
                            </form>
                        </ili>
                    </ul>
            </div>



<?php   

elseif(getUsersRole()=="admin"):


?>

<!------------------------------navigationBar Of the admin  user------------------->
            <a class="navbar-brand" href="#"><img src="img/logo.png"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                      <a class="nav-link" href="index.php">Главная</a>
                      </li>

                      <li class="nav-item">
                    <a class="nav-link" href="edit-categories.php">Категории</a>
                  </li>        

                     <li class="nav-item">
                     <a class="nav-link" href="edit-products.php">Товары</a>
                       </li>

                    <li class="nav-item">
                      <a class="nav-link" href="edit-orders.php">Заказы</a>
                    </li>
                            
                 </ul>
                 <ul class="nav navbar-nav flex-row justify-content-between ml-auto">
                <li class="nav-item order-2 order-md-1"><a href="#" class="nav-link" title="settings"><i class="fa fa-cog fa-fw fa-lg"></i></a></li>
                <li class="dropdown order-1">
                    <button type="button" id="dropdownMenu1" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">Мой профиль<span class="caret"></span></button>
                    <ul class="dropdown-menu dropdown-menu-right mt-2">
                       <li class="px-3 py-2">
                           <form class="form" role="form">
                                <div class="form-group">
                                    <?php
                                    echo "ADMINISTRATOR: " . $_SESSION["firstname"] . " " . $_SESSION["surname"];
                                    ?>
                                </div>
                                <div class="form-group">
                                    
                                </div>
                                <div class="form-group">
                                    <a href="logout.php" type="submit" class="btn btn-primary btn-block">Выйти</a>
                                </div>
                            </form>
                        </li>
                    </ul>
            </div>

            <?php 
                endif
            ?>
            </nav>
</section>
 