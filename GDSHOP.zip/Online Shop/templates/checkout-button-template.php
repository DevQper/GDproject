<?php
if (session_status() == PHP_SESSION_NONE) {session_start();}

if(!empty($_SESSION["userid"]) && !empty($_SESSION["role"]) && $_SESSION["role"] == "user"):
?>
        <a href='confirmed-order.php' class ='btn btn-primary'>Оформить заказ</a>
<?php
else:
?>
        <p>Войдите в свой профиль чтобы оформить заказ<p>

<?php 
endif
?>