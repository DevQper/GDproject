<?php 
require_once "models/Products.php";

$resultArr = false;

if(!empty($_GET['orderid']))
{

    $resultArr = getOrdersProducts($_GET['orderid']);
}

else
{

    $resultArr = getProductsAndCategoriesInStock();
}
if($resultArr):

?>
<div id="products">
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Товар</th>
      <th scope="col">Цена</th>
      <th scope="col">Категория</th>
      <th scope="col">Фото</th>
      <th></th>
    </tr>
    </thead>
    <?php
     foreach($resultArr as $row):
    ?>
  <tbody>
    <tr id='<?php echo $row["ProductID"] ?>' class='Row <?php echo $row["CategoryID"]; ?>'>
      <td><?php echo $row["Product"]; ?></td>
      <td><?php echo $row["Price"]; ?></td>
      <td><?php echo $row["Category"]; ?></td>
      <td><?php echo "<img src='data:image/jpeg;base64," . base64_encode($row["Picture"]) ."' class='product-image'/>"; ?></td>
      <td>
      <?php 
      if (empty($_GET['orderid'])):
        ?>
        <button class="btn btn-success" onclick='addToBasket(<?php echo $row["ProductID"]; ?>)'>Добавить в карзину</button>
      <?php 
    endif; 
    ?>
      </td>
    </tr>
      </tbody>
     <?php endforeach; ?>
</table>
</div>

     <?php endif; ?>