<?php 

require_once "models/Products.php";

$resultArr = getProductsAndCategories();

if($resultArr):

?>
<div id="products">
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Product</th>
      <th scope="col">Cost</th>
      <th scope="col">Price</th>
      <th scope="col">Category</th>
      <th scope="col">Quantity</th>
      <th scope="col">Picture</th>
    </tr>

    <?php
     foreach($resultArr as $row):
    ?>


  </thead>
  <tbody>
    <tr id='<?php echo $row["ProductID"]; ?>' class='Row <?php echo $row["CategoryID"]; ?>'>
      <td><?php echo $row["Product"]; ?></td>
      <td><?php echo $row["Cost"]; ?></td>
      <td><?php echo $row["Price"]; ?></td>
      <td><?php echo $row["Category"]; ?></td>
      <td><?php echo $row["Quantity"]; ?></td>
      <td><?php echo "<img src='data:image/jpeg;base64," . base64_encode($row["Picture"]) ."' class='product-image'/>"; ?></td>
      <td>
      <a href="update-product.php?productid=<?php echo $row["ProductID"]; ?>" class="btn btn-success"><i class="fa fa-edit"></i></a>
      <a href="delete-product.php?productid=<?php echo $row["ProductID"]; ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
      </td>
    </tr>
      </tbody>
     <?php endforeach; ?>
</table>
</div>

     <?php endif; ?>