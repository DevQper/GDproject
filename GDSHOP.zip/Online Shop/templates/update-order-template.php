<?php 
require_once "models/Orders.php";
require_once "models/Users.php";   

if(!empty($_GET["orderid"])):
    
  $resultArrUsers = getUsers();
  $resultArrOrders = getOrdersDetailsByID($_GET['orderid']);

    if($resultArrOrders && !empty($resultArrOrders[0]) && $resultArrUsers):
        $rowOrder = $resultArrOrders[0];
?>

<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center mb-5">Изменить категорию</h2>
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="card border-secondary">
                        <div class="card-header">
                               <h3 class="mb-0 my-2">Введите новые данные категории</h3>
                              </div>
                                       <div class="card-body">
                                        <form action="update-order-submit.php" method="post" class="input-form"> 
                                         <input name="OrderID" type="hidden" value="<?php echo $rowOrder["OrderID"]; ?>">

                                         <label for="date">Дата</label>
                                         <br/>
                                         <input type="date" placeholder="Дата заказа" name="Date" value="<?php echo $rowOrder["Date"]; ?>" required>
                                         <br/>
                                         <br/>

                                         <label for="Paid">Оплачено?</label>
                                         <input type="checkbox" name="Paid" value="1" <?php echo $rowOrder["Paid"] ? "checked" : ""; ?>>
                                         <br/>
                                         <br/>

                                         <label for="UserID">Имя покупателя</label>
                                         <br/>
                                         <select name="UserID" required>
                                         <?php 
                                         foreach($resultArrUsers as $rowUser):
                                            ?>

                                        <option <?php echo $rowOrder["UserID"]==$rowUser["UserID"]? "selected": ""; ?> value="<?php echo $rowUser["UserID"]; ?>"><?php echo $rowUser["Firstname"]; ?><?php echo $rowUser["Surname"]; ?></option>

                                        <?php 
                                        endforeach;
                                        ?>
                                        </select>
                                        <br/>
                                        <br/>

                                        <input type="submit" value="Submit" class="btn btn-primary">

                                        </form>
                                                </div> 
                                          </div>
                                 </div>  
                         </div>
                     </div>
                 </div>
            <!--/row-->

             </div>
        <!--/col-->
         </div>
    <!--/row-->
     </div>
<!--/container-->

<?php 
endif;
endif;
?> 