<?php 
require_once "models/Products.php";
require_once "models/Categories.php";   

    
  $resultArrCategories = getCategories();
 

    if($resultArrCategories):


?>

<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center mb-5">Добавить товар</h2>
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="card border-secondary">
                        <div class="card-header">
                               <h3 class="mb-0 my-2">Введите данные товара</h3>
                              </div>
                                       <div class="card-body">
                                        <form action="insert-product-submit.php" method="post" enctype ="multipart/form-data" class="input-form"> 
                                         <div class="form-group">
                                          <label for="Product">Название продукции</label>
                                          <br/>
                                           <input type="text" class="form-control" name="Product" value="" required="" >
                                           </div>
                                           <br/>
                                           <br/>
                                           <div class="form-group">
                                          <label for="Cost">Цена </label>
                                          <br/>
                                           <input type="number" class="form-control" step="any" min="0" name="Cost" value="" required="" >
                                           </div>
                                           <br/>
                                           <br/>
                                           <div class="form-group">
                                          <label for="Price">Цена продажи </label>
                                          <br/>
                                           <input type="number" class="form-control" step="any" min="0" name="Price" value="" required="">
                                           </div>
                                           <br/>
                                           <br/>
                                           <div class="form-group">
                                          <label for="Quantity">Количество</label>
                                          <br/>
                                           <input type="number" class="form-control" step="1" min="0" name="Quantity" value="" required="">
                                           </div>
                                           <br/>
                                           <br/>
                                           <div class="form-group">Фото товара 300х300</label>
                                           <input type="file" name="Picture" required="" >
                                           <br/>
                                           <br/>
                                           <div class="form-group">
                                          <label for="Quantity">Категория</label>
                                           <br/>
                                           <select name="CategoryID" required="" >
                                          <?php
                                           foreach ($resultArrCategories as $rowCategory):
                                            ?>
                                           <option value ="<?php echo $rowCategory["CategoryID"]; ?>"?><?php echo $rowCategory["Category"]; ?></option>
                                          <?php
                                           endforeach;
                                           ?>
                                           </select>
                                           <br/>
                                           <br/>
                                           </div>

                                           </div>
                                           
                                                   <button type="submit" class="btn btn-primary">Ввести</button>
                                        </form>
                                                </div> 
                                          </div>
                                 </div>
                         </div>
                     </div>
                 </div>
            <!--/row-->

             </div>
        <!--/col-->
         </div>
    <!--/row-->
     </div>
<!--/container-->

<?php 
endif;
?>