<?php
require "includes/authorisation-admin.php";

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php"; 

require_once "models/Orders.php";

if(!empty($_POST['OrderID']) &&
!empty($_POST['Date']) &&
!empty($_POST['UserID']))
{
    
    updateOrder (
        $_POST['OrderID'], $_POST['Date'],
        !empty($_POST['Paid'])? 1 : 0, $_POST['UserID']);

        redirect("edit-orders.php", false);
}

?>