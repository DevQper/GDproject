//Show-Hide table rows by row id
function showHideRows(checkBox)
{
	var rowClass = "Row " + checkBox.getAttribute("id");
	var rows = document.getElementsByClassName(rowClass);
	for(i = 0; i < rows.length; i++)
	{
		if(checkBox.checked)
		{
			rows[i].style.display = "table-row";
		}
		else
		{
			rows[i].style.display = "none";
		}
	}
}

//Add product to basket
function addToBasket(productID)
{
  	var getURL = 'add-to-basket.php?productid=' + productID;
	var xhr = new XMLHttpRequest();
	xhr.open('GET', getURL);
	xhr.onload = function() {
    if (xhr.status === 200 && xhr.responseText == "true") {
		
		alert("Добавлено в корзину.");
		//Refresh the page - used so that basket items are shown correctly
		location.reload();
    }
    else {
		alert("Не добавлено в корзину.");
    }
	};
	xhr.send(); 
}

//Remove product from basket
function removeFromBasket(productID)
{
  	var getURL = 'remove-from-basket.php?productid=' + productID;
	var xhr = new XMLHttpRequest();
	xhr.open('GET', getURL);
	xhr.onload = function() {
    if (xhr.status === 200 && xhr.responseText == "true") {
		alert("Удалено из корзины");
		//Refresh the page - used so that basket items are shown correctly
		location.reload();
    }
    else {
		alert("Не удалено из корзины.");
    }
	};
	xhr.send();
}

