<?php
require "includes/authorisation-admin.php";

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

include "pages/insert-product-page.php"


?>