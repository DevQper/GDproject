<?php 
if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";
//assume that we will fail
$response = "false";
// check that we have productid
if(!empty($_GET['productid']))

{
// check that the basket exists in the session
    if(!empty($_SESSION['basket']))
    {
// search the array to see if the basket contains the product, get the index of where it is
       $foundIndex = array_search($_GET['productid'], $_SESSION['basket']);

       // if the item in the basket remove it 
       if($foundIndex !== false)
       {
           //remove the product
           unset($_SESSION['basket'][$foundIndex]);
           //re-index the array
           $_SESSION['basket'] = array_values($_SESSION['basket']);

           //store that we have succeded
           $response = "true";
       }
    }
}
echo $response;
?>