<?php 
require "includes/authorisation-user.php";

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

require_once "models/orders.php";

$orderID = checkout();

if($orderID<0)
{
    redirect("view-basket.php", false);
}

include "pages/confirmed-order-page.php";

?>