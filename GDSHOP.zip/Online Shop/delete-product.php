<?php
require "includes/authorisation-admin.php";

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

require_once "models/Products.php";

if(!empty($_GET["productid"]))
{

    deleteProduct($_GET["productid"]);

}

redirect("edit-products.php", false);

?>