<?php
if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";?>
  
  <!DOCTYPE html>
<html>
<?php include "templates/head-template.php"?>
<body>
<?php include "templates/nav-template.php"?>


        <!----------------slider-------------->
        <div id="slider"> 
            <div id="headerSlider" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">    
                  <li data-target="#headerSlider" data-slide-to="0" class="active"></li>
                  <li data-target="#headerSlider" data-slide-to="1"></li>
                  <li data-target="#headerSlider" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="img/banner-1.jpg" class="d-block img-fluid">
                    <div class="carousel-caption">
                         <h5>Выберите надежных производителей</h5>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="img/banner-2.jpg" class="d-block img-fluid">
                    <div class="carousel-caption">
                        <h5>Закажите доставку необходимых товаров</h5>
                   </div>
                  </div>
                  <div class="carousel-item">
                    <img src="img/banner-3.jpg" class="d-block img-fluid">
                    <div class="carousel-caption">
                        <h5>Пополните свой магазин в один клик!</h5>
                   </div>
                  </div>
                </div>
                <a class="carousel-control-prev" href="#headerSlider" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#headerSlider" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
        </div>

        <!----------------ABOUT SECTION-------------->
<section id="about">
 <div class="container">
     <div class="row">
         <div class="col-md-6">
             <h2>О нас</h2>
             <div class="about-content">
                Мы - это современная логистическая компания, которая занимается логистикой в интернете. 
                Нашей целью является улучшение качества обслуживания, уменьшение времени и затрат на 
                пополнение и осуществление заказов нацеленных на закупку необходимых продуктов питания,
                 полуфабрикатов, кондитерских, молочных изделий, алкогольной, табачной продукции и тд.
                 Мы хотим сократить ваше время и затраты на процесс заказа товаров.
             </div>
             <button type="button" class="btn btn-primary">Читать дальше</button>
         </div>
         <div class="col-md-6 skills-bar">
                <p>Развитие в сфере информационных технологий</p>
                <div class="progress">
                <div class="progress-bar" style="width:80%;">80%</div>
                </div>
                <p>Опыт на рынке инноваций</p>
                <div class="progress">
                <div class="progress-bar" style="width:85%;">85%</div>
                </div>
                <p>Логистика</p>
                <div class="progress">
                <div class="progress-bar" style="width:75%;">75%</div>
                </div>
                <p>Опыт в доведении проектов до конца</p>
                <div class="progress">
                <div class="progress-bar" style="width:90%;">90%</div>
                </div>
         </div>
     </div>
 </div>
</section>

<!-------Services---------->
<section id="services">
    <div class="container">
        <h1>Наши Сервисы</h1>
        <div class="row services">
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-desktop"></i>
                </div>
                <h3>Web Разработка</h3>
                <p>Наша команда - это исключительно проффессиональные и креативные веб-разработчики, дизайнеры и инженеры готовые решать ваши проблемы</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-tablet"></i>
                </div>
                <h3>Мобильная Разработка</h3>
                <p>Мобильная разработка является важной частью любого проекта, именно по-этой причине мы предоставляем возможности мулти-платформенности своим клиентам</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-line-chart"></i>
                </div>
                <h3>Информационный Маркетинг</h3>
                <p>Информационный маркетинг это ключевая часть нашей работы, каждый специалист это понимает, без этого не было бы нашей компании</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-paint-brush"></i>
                </div>
                <h3>Web Дизайн</h3>
                <p>Мы акцентируем особое внимание на дизайн и расчитываем на соответсвие всем стандартам современного дизайна</p>
            </div> 
        </div>
    </div>
     
</section>


<!--------------TEAM MEMBERS SECTION--------------->
<section id="team">
    <div class="container">
        <h1>Наша Команда</h1>
        <div class="row">
            <div class="col-md-3 profile-pic text-center">
                <div class="img-box">
                    <img src="img/team1.jpg" class="img-responsive">
                    <ul>
                    <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                    <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                    <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </div>
                <h2>Асет Аскарбеков</h2>
            <h3>Основатель / Исполнительный Директор</h3>
            <p>Идеи - это смысл жизни, инновации - стиль жизни.</p>
            </div>

            <div class="col-md-3 profile-pic text-center">
                <div class="img-box">
                    <img src="img/team2.jpg" class="img-responsive">
                    <ul>
                    <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                    <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                    <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </div>
                <h2>Жолдыбаев Акжан</h2>
            <h3>Основатель / Маркетинг Директор</h3>
            <p>Граммотный Маркетинг это когда ты можешь продать воздух самому себе.</p>
            </div>

            <div class="col-md-3 profile-pic text-center">
                <div class="img-box">
                    <img src="img/team3.jpg" class="img-responsive">
                    <ul>
                    <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                    <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                    <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </div>
                <h2>Мадина Елеукина</h2>
            <h3>Основатель / IT Директор</h3>
            <p>Интернет это наше все!</p>
            </div>

            <div class="col-md-3 profile-pic text-center">
                <div class="img-box">
                    <img src="img/team4.jpg" class="img-responsive">
                    <ul>
                    <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                    <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                    <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </div>
                <h2>Адиль Бильгибаев</h2>
            <h3>Лицо компании / Брэнд-мэйкер</h3>
            <p>Правильный ракурс решает все!</p>
            </div>
            
        </div>
    </div>


</section>
<!--------------THE END OF TEAM MEMBERS SECTION--------------->


<!-----------------------PROMO SECTION------------------------>

<section id="promo">
    <div class="container">
        <p>Для сотрудничества - просто, свяжитесь с нами.</p>
        <a href="#contact" class="btn btn-primary">Связаться</a>
    </div>
</section>

<!-----------------THE END OF PROMO SECTION------------------->





<!---------------------------TESTIMONIALS------------------------------>

<section id="testimonials">
    <div class="container">
        <h1>Отзывы</h1>
        <p class ="text-center" >Довольные партнеры и пользователи</p>
        <div class="row">
            <div class="col-md-4 text-center" >
              <div class="profile">
                  <img src="img/user1.jpg" class="user">
                  <blockquote>Действительно удобное приложение. Я бы даже сказал инновация.</blockquote>
                    <h3>Федорец  Константин Викторович <span>Председатель Правления АО «Рахат»</span></h3>
              </div>
            </div>

            <div class="col-md-4 text-center" >
                <div class="profile">
                    <img src="img/user2.jpg" class="user">
                    <blockquote>Видимо нужно будет уволить торговых представителей, подумал я.</blockquote>
                      <h3>Александр Глусь <span>Основатель компании Nemiroff</span></h3>
                </div>
              </div>

              <div class="col-md-4 text-center" >
                <div class="profile">
                    <img src="img/user3.jpg" class="user">
                    <blockquote>Идея хорошая!</blockquote>
                      <h3>Азамат Токтаргалиев <span>Председатель правления ТОО Маслодел</span></h3>
                </div>
              </div>

              <div class="col-md-4 text-center" >
                <div class="profile">
                    <img src="img/user4.jpg" class="user">
                    <blockquote>Очень удобно, открыл новый магазин и сразу же все заказал, через неделю пришло, надеюсь это так будет работать?</blockquote>
                      <h3>Корченко Олег <span>Владелец магазина "Ксения"</span></h3>
                </div>
              </div>

              <div class="col-md-4 text-center" >
                <div class="profile">
                    <img src="img/user5.jpg" class="user">
                    <blockquote>Очень жду запуска проекта!</blockquote>
                      <h3>Владлен Рыспаев <span>Владелец сети супермаркетов "Алтын-Парфюм"</span></h3>
                </div>
              </div>
        </div>

    </div>
</section>


<!---------------------------GET IN TOUCH SECTION----------------------------->

<section id="contact">
    <div class="container">
        <h1>Связь с нами</h1>
        <div class="row">
            <div class="col-md-6">
                <form class="contact-form" action="">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your Name" name="" id="">
                    </div>


                    <div class="form-group">
                        <input type="number" class="form-control" placeholder="Phone Number" name="" id="">
                    </div>


                    <div class="form-group">
                        <input type="email" class="form-control" placeholder="Email Adress" name="" id="">
                    </div>


                    <div class="form-group">
                        <textarea class="form-control" rows="4" placeholder="Your Message" name="" id=""></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">SEND MESSAGE</button>

                </form>
            </div>


            <div class="col-md-6 contact-info">
                <div class="follow"><b>Address</b> <i class="fa fa-map-marker"></i> Shymkent zhol, Petropavlovsk, KZ </div>
                
         
                <div class="follow"><b>Phone</b> <i class="fa fa-phone"></i> +7 777 77 7777, +7 705 70 5777 </div>
                
            
                <div class="follow"><b>Email</b> <i class="fa fa-envelope-o"></i> Detsel7777@gmail.com </div>
                
                
                <div class="follow"><label><b>Get Social</b></label> 
                    <a href="#"><i class="fa fa-facebook"></i></a> 
                    <a href="#"><i class="fa fa-linkedin"></i></a>
                    <a href="#"><i class="fa fa-youtube"></i></a>
                    <a href="#"><i class="fa fa-google-plus"></i></a>
                </div>
            </div>
            
        </div>
    </div>
</section>

<!-------------------------------THE END OF GET IN TOUCH SECTION----------------------------->
<?php include "templates/footer-template.php"?>



<script src="js/smooth-scroll.js"></script>     
<script>
	var scroll = new SmoothScroll('a[href*="#"]');
</script>

</body>
</html> 