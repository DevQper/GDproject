<?php
//forced redirect function
function redirect ($url, $delayed = false, $permanent = false)
{
  if (!headers_sent() && !$delayed)
  {
    header('Location:' . $url, true, ($permanent === true) ? 301:302);
  }
  else
  {
    echo "<a href = '$url'>Click here.</a>";
    echo "<script type='text/javasript'>" . 
    "setTimeout (function () {".
    "window.location.href= '$url';},5000);".
    "</script>";
  }
  exit();
}
?>