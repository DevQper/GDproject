<?php
$servername = "localhost";
$username = "asa";
$password = "Asset123789";
$dbname = "asa_Supplymer";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

//Set character set for Cyrillic
mysqli_set_charset($conn, "utf8");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
