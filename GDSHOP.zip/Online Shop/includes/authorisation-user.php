<?php
if (session_status() == PHP_SESSION_NONE) {session_start();}
/*
code to timeout the session if the user hasn't used a secure page for more 
*/
$time= $_SERVER['REQUEST_TIME']; //the current time
$timeout_duration = 3600; //timeout specified in seconds
if( isset ($_SESSION['LastActivity']) &&
($time - $_SESSION['LastActivity']) > $timeout_duration) // if true, the user will be kicked from the session
{
//Logaut the user by destroying the session
session_unset();
session_destroy();
}
$_SESSION['LastActivity'] = $time;
/* 
Code to check the user session and roles. If there is no session or the roles are insuggicient, kill everything
*/
if(empty($_SESSION["userid"]) || empty($_SESSION["role"]) || ($_SESSION["role"]!="user" && $_SESSION["role"]!="admin"))
{
die("Not authorised.");
    }
?>