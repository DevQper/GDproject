<?php 

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

require_once "models/Users.php";

logout();

redirect("index.php", false);
?>