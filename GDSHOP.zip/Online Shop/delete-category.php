<?php
require "includes/authorisation-admin.php";

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

require_once "models/Categories.php";

if(!empty($_GET["categoryid"]))
{

    deleteCategory($_GET["categoryid"]);

}

redirect("edit-categories.php", false);

?>