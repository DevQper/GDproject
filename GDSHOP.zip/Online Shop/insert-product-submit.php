<?php
require "includes/authorisation-admin.php";

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

require_once "models/Products.php";

if (!empty($_POST["Product"]) &&
!empty($_POST["Cost"]) &&
!empty($_POST["Price"]) &&
!empty($_POST["Quantity"]) &&
!empty($_POST["Picture"]) &&
!empty($_POST["CategoryID"]))
{

    insertProduct($_POST["Product"], $_POST["Cost"],
    $_POST["Price"], $_POST["Quantity"],
file_get_contents($_FILES["Picture"]["tmp_name"]),
$_POST["CategoryID"]);

    redirect("edit-products.php", false);
}

?>