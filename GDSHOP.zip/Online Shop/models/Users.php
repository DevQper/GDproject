<?php
if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/db-connect.php";    //Запрашиваем файл для подключения к ДБ


function login($emailAddress, $password)                         /* login in the user with the given emailaddressamd password */
{

if(!empty($emailAddress) && !empty($password))                     /* make sure both email and password are present*/

{

global $conn;

/* check that the email address is in the database */

$stmt = mysqli_prepare ($conn, "SELECT UserID, EmailAddress, Firstname,	Surname, HashedPassword, Role
FROM Users WHERE EmailAddress=?" );

mysqli_stmt_bind_param($stmt, "s" , $emailAddress);
 
$success = mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$row = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if ($success && mysqli_num_rows($result)>0)

{

//check if the password matches the passowrd hash

if(password_verify($password, $row["HashedPassword"]))

{

/* set the users session variables */

$_SESSION["userid"] = $row["UserID"];
$_SESSION["emailaddress"] = $row["EmailAddress"];
$_SESSION["firstname"] = $row["Firstname"];
$_SESSION["surname"] = $row["Surname"]; 
$_SESSION["role"] = $row["Role"];

}
}
mysqli_close($conn);
}
}

/* logout session works by destroying all sessions */

function logout()

{

session_unset();

session_destroy();

}

/*  checks if any user logged in or not, returns true or false  */


function isAUserLoggedIn()
{

  $loggedIn = !empty($_SESSION["userid"]) && $_SESSION["userid"] >=0;
  return $loggedIn;

}

/* gets the role of logged in user */
function getUsersRole()
{
      $userRole = "";

          if (!empty($_SESSION["role"]))
    {
         $userRole = $_SESSION["role"];

     }
   return $userRole;
}

/* gets all details of user logged in */

function getLoggedInUser()
{

  global $conn;

  $resultArr = false;
  
  //check that there is user logged in

  if(!empty($_SESSION['userid']))
  {

    $stmt = mysqli_prepare($conn, "SELECT * FROM Users WHERE UserID=?");

    mysqli_stmt_bind_param($stmt, "i", $_SESSION['userid']);

    $success = mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if($success && mysqli_num_rows($result)>=0)
    {

      $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);

    }
  }
  return $resultArr;
}

function userExists($emailAddress)
{

  global $conn;
  $exists = false;

  $stmt = mysqli_prepare ($conn, "SELECT EmailAddress FROM Users WHERE EmailAddress = ?");
  mysqli_stmt_bind_param($stmt, "s", $emailAddress);
  $success = mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  mysqli_stmt_close($stmt);

  if( $success && mysqli_num_rows($result)>=1 )
  {

    $exists = true;
  }
  return $exists;
}


function fristUser()
{

  global $conn;

  $first = false;

  $stmt = mysqli_prepare ($conn, "SELECT COUNT(*) AS NumUsers FROM Users");

  $success = mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  mysqli_stmt_close($stmt);

  if($success && mysqli_num_rows($result)>=0)
  {

    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
    if(!empty($resultArr[0]) && $resultArr[0]["NumUsers"]==0)
    {

      $first = true;
    }
  }
  return $first;
}

function getUsers()                                                                                    // декларируем функцию, которая будет запрашивать все из таблицы категорий
{
  global $conn;                                                                                       //создаем отдельное подключение 


  $stmt = mysqli_prepare($conn, "SELECT * FROM Users;");                                                /*Пишем SQL query для получения всех данных с таблицы */
                                                                                                          
                                                                                                          
/*  создаем переменные с запуском и получением результатов Query */

  $success = mysqli_stmt_execute($stmt);

  $result = mysqli_stmt_get_result($stmt);

  
  
  $resultArr = false;                                                                       // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
  
  /* создаем двумерный массив и получаем результат */
  
  if($success && mysqli_num_rows($result)  >=0 )
  {
  
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
  } 
  
  mysqli_stmt_close($stmt);
  
  
  return $resultArr;
}


function getUser($userID) // декларируем функцию
{
  
  global $conn;                 //создаем отдельное подключение 
  
  $stmt = mysqli_prepare($conn, "SELECT * FROM Users WHERE UserID=?;");  /*Пишем SQL query для получения ID категорий с таблицы  с таблицы */
  
  mysqli_stmt_bind_param($stmt, "i", $userID); // задаем параметры для результата 
  
   //  создаем переменные с запуском и получением результатов Query
  
  $success = mysqli_stmt_execute($stmt);
  
  $result = mysqli_stmt_get_result($stmt);
  
  // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
  
  $resultArr = false;
  
  // создаем двумерный массив и получаем результат
  
  if($success && mysqli_num_rows()  >=0 )
  
  {
  
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
  
  } 
  
  mysqli_stmt_close($stmt);
  
  return $resultArr;
}




function updateUser	($userID, $emailAddress, $mobileNumber, $titel, $firstname, $surname, $apartmentNumber,	$street, $city,	$region, $postcode, $country, $hashedPassword, $role) // декларируем функция добавления 

{ 

  global $conn; // создаем соеденение 

  $stmt = mysqli_prepare($conn, "UPDATE Users SET EmailAddress=?	MobileNumber=?	Title=?	Firstname=?	Surname=?	ApartmentNumber=?	Street=?	City=?	Region=?	Postcode=?	Country=?	HashedPassword=?	Role=?
  WHERE UserID =?;");  // пишем SQL Query 

  mysqli_stmt_bind_param($stmt, "sssssssssssssi", $emailAddress, $mobileNumber, $titel, $firstname, $surname, $apartmentNumber, $street, $city,	$region, $postcode, $country, $hashedPassword, $role, $userID); // giving parametrs to data beiing inputing 

    $success = mysqli_stmt_execute($stmt);  //dealare success

    mysqli_stmt_close($stmt); // close statement 

  return $success;

}





function insertUser($emailAddress, $mobileNumber, $titel, $firstname, $surname, $apartmentNumber,	$street, $city,	$region, $postcode, $country, $hashedPassword, $role) // декларируем функция добавления 

{ 

  global $conn; // создаем соеденение 

  $stmt = mysqli_prepare($conn, "INSERT INTO Users (  EmailAddress,	MobileNumber,	Title,	Firstname,	Surname,	ApartmentNumber,	Street,	City,	Region,	Postcode,	Country,	HashedPassword,	Role) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);");  // пишем SQL Query 

  mysqli_stmt_bind_param($stmt, "sssssssssssss",  $emailAddress, $mobileNumber, $titel, $firstname, $surname, $apartmentNumber,	$street, $city,	$region, $postcode, $country, $hashedPassword, $role); // giving parametrs to data beiing inputing 

    $success = mysqli_stmt_execute($stmt);  //dealare success

    mysqli_stmt_close($stmt); // close statement 

  return $success;

}



function deleteUser($userID)

{

    global $conn; // создаем соеденение 

  $stmt = mysqli_prepare($conn, "DELETE * FROM Users WHERE UserID=?;");  // пишем SQL Query 

  mysqli_stmt_bind_param($stmt, "i", $userID); // giving parametrs to data beiing inputing 

    $success = mysqli_stmt_execute($stmt);  //dealare success

    mysqli_stmt_close($stmt); // close statement 

  return $success;

} 


?>
