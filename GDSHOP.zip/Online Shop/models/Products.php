<?php
 require_once "includes/db-connect.php";    //Запрашиваем файл для подключения к ДБ


 function getOrdersProducts($orderID)
 {
     global $conn;
     
     $stmt = mysqli_prepare ($conn, 
     "SELECT *
      FROM (OrdersProducts INNER JOIN Products ON OrdersProducts.ProductID = Products.ProductID) 
     INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID 
     WHERE OrdersProducts.OrderID=?;");

     mysqli_stmt_bind_param($stmt, "i", $orderID);

     $success = mysqli_stmt_execute($stmt);
     $result = mysqli_stmt_get_result($stmt);

     $resultArr = false;
     if($success && mysqli_num_rows($result)>=0)
     {
         $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
     }
     mysqli_stmt_close($stmt);
     return $resultArr;
 }

 function getBasketProducts()
 {
     $resultArr = false;
     if(!empty($_SESSION['basket']))
     {
         global $conn;

         $products = implode(", ", $_SESSION['basket']);
         
         $stmt = mysqli_prepare ($conn, 
         "SELECT * FROM Products INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID 
         WHERE Products.ProductID IN (" . $products . ")");
         $success = mysqli_stmt_execute($stmt);
         $result = mysqli_stmt_get_result($stmt);
         if($success && mysqli_num_rows($result) >=0 )
         {
             $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
         }
     }
     return $resultArr;
 }

 function getProductsAndCategoriesInStock()
 {
    global $conn;                 //создаем отдельное подключение 

    $stmt = mysqli_prepare($conn, 
    "SELECT * FROM Categories INNER JOIN Products ON Categories.CategoryID = Products.CategoryID WHERE Quantity>0;");  /*Пишем SQL query для получения всех данных с таблицы */
     //  создаем переменные с запуском и получением результатов Query
    $success = mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
    $resultArr = false;
    // создаем двумерный массив и получаем результат
    if($success && mysqli_num_rows($result) >=0 )
    {
      $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
    } 
    mysqli_stmt_close($stmt);
    return $resultArr;

 }

 function getProductsAndCategories()
 {

    global $conn;                 //создаем отдельное подключение 
    $stmt = mysqli_prepare($conn, "SELECT *
     FROM Categories INNER JOIN Products ON Categories.CategoryID = Products.CategoryID;");  /*Пишем SQL query для получения всех данных с таблицы */
     //  создаем переменные с запуском и получением результатов Query
    $success = mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
    $resultArr = false;
    // создаем двумерный массив и получаем результат
    if($success && mysqli_num_rows($result) >=0 )
    {
      $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
    } 

    mysqli_stmt_close($stmt);
    
    return $resultArr;
 }
    
function getProducts() // декларируем функцию, которая будет запрашивать все из таблицы категорий
{
  global $conn;                 //создаем отдельное подключение 
  $stmt = mysqli_prepare($conn, "SELECT * FROM Products;");  /*Пишем SQL query для получения всех данных с таблицы */
   //  создаем переменные с запуском и получением результатов Query
  $success = mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
  $resultArr = false;
  // создаем двумерный массив и получаем результат
  if($success && mysqli_num_rows()  >=0 )
  {
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
  } 
  mysqli_stmt_close($stmt);
  return $resultArr;
}


function getProduct($productID) // декларируем функцию
{
  global $conn;                 //создаем отдельное подключение 
  $stmt = mysqli_prepare($conn, "SELECT * FROM Products WHERE ProductID=?;");  /*Пишем SQL query для получения ID категорий с таблицы  с таблицы */
  mysqli_stmt_bind_param($stmt, "i", $productID); // задаем параметры для результата 
   //  создаем переменные с запуском и получением результатов Query
  $success = mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
  $resultArr = false;
  // создаем двумерный массив и получаем результат
  if($success && mysqli_num_rows($result) >=0 )
  {
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
  } 
  mysqli_stmt_close($stmt);
  return $resultArr;
}

function updateProduct($productID, $product, $cost, $price, $quantity, $picture, $categoryID) // декларируем функция добавления 
{ 
  global $conn; // создаем соеденение 
  $stmt = mysqli_prepare ($conn, "UPDATE Products SET Product = ?, Cost = ?, Price = ?, Quantity = ?, Picture = ?, CategoryID = ? WHERE ProductID = ?;");  // пишем SQL Query 
  mysqli_stmt_bind_param($stmt, "sddisii", $product, $cost, $price, $quantity, $picture, $categoryID, $productID); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success
    mysqli_stmt_close($stmt);
  return $success;
}

function updateProductNoPicture($productID, $product, $cost, $price, $quantity, $categoryID) // декларируем функция добавления 
{ 
  global $conn; // создаем соеденение 
  $stmt = mysqli_prepare ($conn, "UPDATE Products SET Product = ?, Cost = ?, Price = ?, Quantity = ?, CategoryID = ? WHERE ProductID = ?;");  // пишем SQL Query 
  mysqli_stmt_bind_param($stmt, "sddiii", $product, $cost, $price, $quantity, $categoryID, $productID); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success
    mysqli_stmt_close($stmt);
  return $success;
}

  

function insertProduct($product, $cost, $price, $quantity, $picture, $categoryID) // декларируем функция добавления 
{ 
  global $conn; // создаем соеденение 
  $stmt = mysqli_prepare($conn, "INSERT INTO Products (Product, Cost, Price, Quantity, Picture, CategoryID) VALUES (?, ?, ?, ?, ?, ?);");  // пишем SQL Query 
  mysqli_stmt_bind_param($stmt, "sddisi", $product, $cost, $price, $quantity, $picture, $categoryID); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success
    mysqli_stmt_close($stmt); // close statement 
  return $success;
}

function deleteProduct($productID)
{
    global $conn; // создаем соеденение 
  $stmt = mysqli_prepare($conn, "DELETE FROM Products WHERE ProductID=?;");  // пишем SQL Query 
  mysqli_stmt_bind_param($stmt, "i", $productID); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success
    mysqli_stmt_close($stmt); // close statement 
  return $success;
}

  

?>