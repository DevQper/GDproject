<?php
 require_once "includes/db-connect.php";                                                      //Запрашиваем файл для подключения к ДБ
 
function getCategories()                                                                // декларируем функцию, которая будет запрашивать все из таблицы категорий
{
  global $conn;   
  
                                                                                      //создаем отдельное подключение 
$stmt = mysqli_prepare($conn, "SELECT * FROM Categories;");                                      /*Пишем SQL query для получения всех данных с таблицы */
                                                                                               //  создаем переменные с запуском и получением результатов Query
$success = mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
                                                                                              // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
$resultArr = false;     
                                                                                               // создаем двумерный массив и получаем результат
 if($success && mysqli_num_rows($result)  >=0 )
 {
  
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
  } 
  
  mysqli_stmt_close($stmt);
  
  
  return $resultArr;
}

function getCategory($categoryID) // декларируем функцию
{
  global $conn;                 //создаем отдельное подключение 
  $stmt = mysqli_prepare($conn, "SELECT * FROM Categories WHERE CategoryID=?;");  /*Пишем SQL query для получения ID категорий с таблицы  с таблицы */
  mysqli_stmt_bind_param($stmt, "i", $categoryID); // задаем параметры для результата 
   //  создаем переменные с запуском и получением результатов Query
  $success = mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
  $resultArr = false;
  // создаем двумерный массив и получаем результат
  if($success && mysqli_num_rows($result)  >=0 )
  {
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
  } 
  mysqli_stmt_close($stmt);
  return $resultArr;
}

function updateCategory($categoryID, $category) // декларируем функция добавления 
{ 
  global $conn; // создаем соеденение 
  $stmt = mysqli_prepare($conn, "UPDATE Categories SET Category = ? WHERE CategoryID =?;");  // пишем SQL Query 
  mysqli_stmt_bind_param($stmt, "si", $category, $categoryID); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success
    mysqli_stmt_close($stmt); // close statement 
  return $success;
}


function insertCategory($category) // декларируем функция добавления 
{ 
  global $conn; // создаем соеденение 
  $stmt = mysqli_prepare($conn, "INSERT INTO Categories (Category) VALUES (?);");  // пишем SQL Query 
  mysqli_stmt_bind_param($stmt, "s", $category); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success
    mysqli_stmt_close($stmt); // close statement 
  return $success;
}

function deleteCategory($categoryID)
{
    global $conn; // создаем соеденение 
  $stmt = mysqli_prepare($conn, "DELETE FROM Categories WHERE CategoryID=?;");  // пишем SQL Query 
  mysqli_stmt_bind_param($stmt, "i", $categoryID); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success
    mysqli_stmt_close($stmt); // close statement 
  return $success;
}

  

?>