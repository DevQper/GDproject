<?php
 require_once "includes/db-connect.php";    //Запрашиваем файл для подключения к ДБ

function getOrdersDetailsByID($orderID)
{
    global $conn;
    $stmt = mysqli_prepare($conn, 
    "SELECT Orders.OrderID, Users.UserID, date_format(Orders.Date,'%y-%m-%d') AS Date, Orders.Paid, CONCAT(Users.Firstname, ' ', Users.Surname) AS CustomerName, SUM(Products.Price) AS SaleAmount, SUM(Products.Price-Products.Cost) AS Profit
    FROM ((Products INNER JOIN OrdersProducts ON Products.ProductID = OrdersProducts.ProductID) 
    INNER JOIN Orders ON OrdersProducts.OrderID = Orders.OrderID)
    INNER JOIN Users ON Orders.UserID = Users.UserID 
    WHERE Orders.OrderID = ? 
    GROUP BY Orders.OrderID;");
mysqli_stmt_bind_param($stmt, "i", $orderID);

$success = mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$resultArr = false;

if($success && mysqli_num_rows($result)>=0)
{
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
}
return $resultArr;
}




 function getOrdersDetails()
 {
    global $conn;
    $stmt = mysqli_prepare($conn, 
    "SELECT Orders.OrderID, Users.UserID, date_format(Orders.Date,'%y-%m-%d') AS Date, Orders.Paid, CONCAT(Users.Firstname, ' ', Users.Surname) AS CustomerName, SUM(Products.Price) AS SaleAmount, SUM(Products.Price-Products.Cost) AS Profit
    FROM ((Products INNER JOIN OrdersProducts ON Products.ProductID = OrdersProducts.ProductID) 
    INNER JOIN Orders ON OrdersProducts.OrderID = Orders.OrderID)
    INNER JOIN Users ON Orders.UserID = Users.UserID 
    GROUP BY Orders.OrderID;");

$success = mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$resultArr = false;

if($success && mysqli_num_rows($result)>=0)
{
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
}
return $resultArr;
}

function getAllOrdersTotals()
{
    global $conn;
    
    $stmt = mysqli_prepare ($conn, 
    "SELECT SUM(Products.Cost) AS TotalCost, SUM(Products.Price) AS TotalSales, SUM(Products.Price - Products.Cost) AS TotalProfit 
    FROM Products INNER JOIN OrdersProducts ON Products.ProductID = OrdersProducts.ProductID;");

$success = mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$resultArr = false;

if($success && mysqli_num_rows($result)>=0)
{
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
}
return $resultArr;
}

 function getOrderTotals($orderid)
 {
     global $conn;
     $stmt = mysqli_prepare ($conn, 
     "SELECT (SUM(Products.Price) / 1.12) AS BeforeTaxPrice, (SUM(Products.Price) / 1.12 * 0.12) AS Tax, SUM(Products.Price) AS TotalPrice
     FROM (Orders INNER JOIN OrdersProducts ON Orders.OrderID = OrdersProducts.OrderID) INNER JOIN Products ON OrdersProducts.ProductID = Products.ProductID
     WHERE Orders.OrderID=?;");

     mysqli_stmt_bind_param($stmt, "i", $orderid);
     $success = mysqli_stmt_execute($stmt);
     $result = mysqli_stmt_get_result($stmt);

     $resultArr = false;

     if($success && mysqli_num_rows($result)>=0)
     {
         $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
     }
     return $resultArr;
 }


 function getOrdersProducts($orderid)
 {
     global $conn;
     
     $stmt = mysqli_prepare ($conn, "SELECT Products.ProductID, Products.Product, COUNT(Products.ProductID) AS Quantity, Products.Price, SUM(Price) AS TotalPrice
     FROM (Orders INNER JOIN OrdersProducts ON Orders.OrderID = OrdersProducts.OrderID) INNER JOIN Products ON OrdersProducts.ProductID = Products.ProductID
     WHERE Orders.OrderID=? GROUP BY ProductID;");

     mysqli_stmt_bind_param($stmt, "i", $orderid);

     $success = mysqli_stmt_execute($stmt);
     $result = mysqli_stmt_get_result($stmt);

     $resultArr = false;
     if($success && mysqli_num_rows($result)>=0)
     {
         $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
     }
     return $resultArr;
 }

 function getLoggedInUserLastOrderID()
 {
     global $conn;
     
     $orderID = -1;

     // Check that there are user logged inn
     if(!empty($_SESSION['userid']))
     {
         $stmt = mysqli_prepare ($conn, 
         "SELECT OrderID FROM Orders WHERE UserID = ? ORDER BY OrderID DESC LIMIT 0, 1;");

         mysqli_stmt_bind_param($stmt, "i", $_SESSION['userid']);

         $success = mysqli_stmt_execute($stmt);
         $result = mysqli_stmt_get_result($stmt);

         if($success && mysqli_num_rows($result)>=0)
         {
             $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
             if(!empty($resultArr[0]))
             {
                 $row = $resultArr[0];
                 $orderID = $row["OrderID"];
             }
         }
     }
     return $orderID;
 }

function checkout()
{
//Make orderID -1 to show there is no order yet
    $orderid = -1;

    //check that there are items in the basket and the user logged in
    if(!empty($_SESSION['basket']) && !empty($_SESSION['userid']) && !empty($_SESSION['role']) && $_SESSION['role'] == "user")
    {
        //GET the logged in users id
        $userID = $_SESSION['userid'];

        global $conn;

        //create the order
        $stmt = mysqli_prepare($conn, "INSERT INTO Orders (Date, Paid, UserID) VALUES (NOW(), false, ?);");
        mysqli_stmt_bind_param($stmt, "i", $userID);
        $success = mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if($success)
        {
            // gets the user id made by autoincrement
            $orderid = mysqli_insert_id($conn);

            //Add all the product to the order and reduce their quantities
            foreach($_SESSION['basket'] as $basketItem)
            {

                //add a product to the order
                $stmt = mysqli_prepare ($conn, "INSERT INTO OrdersProducts (OrderID, ProductID) VALUES (?, ?);");
                mysqli_stmt_bind_param($stmt, "ii", $orderid, $basketItem);
                $success = mysqli_stmt_execute($stmt);
                if(!$success) {break; $orderid=-2;}
                
                // reduce the quantity of product
                $stmt = mysqli_prepare ($conn, "UPDATE Products SET Quantity = Quantity - 1 WHERE ProductID=?;");
                mysqli_stmt_bind_param($stmt, "i", $basketItem);
                $success = mysqli_stmt_execute($stmt);
                if(!$success) {break; $orderid=-2;}
            }
        }
        // remove the products from the basket 
        if($success)
        {
            unset($_SESSION['basket']);
        }
    }
}
 
function getOrders() // декларируем функцию, которая будет запрашивать все из таблицы категорий
{
  global $conn;                 //создаем отдельное подключение 
  $stmt = mysqli_prepare($conn, "SELECT * FROM Orders;");  /*Пишем SQL query для получения всех данных с таблицы */
   //  создаем переменные с запуском и получением результатов Query
  $success = mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
  $resultArr = false;
  // создаем двумерный массив и получаем результат
  if($success && mysqli_num_rows()  >=0 )
  {
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
  } 
  mysqli_stmt_close($stmt);
  return $resultArr;
}


function getOrder($orderID) // декларируем функцию
{
  global $conn;                 //создаем отдельное подключение 
  $stmt = mysqli_prepare($conn, "SELECT * FROM Orders WHERE OrderID=?;");  /*Пишем SQL query для получения ID категорий с таблицы  с таблицы */
  mysqli_stmt_bind_param($stmt, "i", $orderID); // задаем параметры для результата 
   //  создаем переменные с запуском и получением результатов Query
  $success = mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  // ставим изначальное массива значение ФОЛС для того что бы на странице ничего не отображало
  $resultArr = false;
  // создаем двумерный массив и получаем результат
  if($success && mysqli_num_rows()  >=0 )
  {
    $resultArr = mysqli_fetch_all($result, MYSQLI_ASSOC);
  } 
  return $resultArr;
}

function updateOrder($orderID, $date, $paid, $userID) // декларируем функция добавления 
{ 
  global $conn; // создаем соеденение 
  $stmt = mysqli_prepare($conn, "UPDATE Orders SET Date=?, Paid=?, UserID=? WHERE OrderID = ?;");  // пишем SQL Query 
  mysqli_stmt_bind_param($stmt, "siii", $date, $paid, $userID, $orderID); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success 
  return $success;
}


function deleteOrderProducts($orderID)
{
    global $conn; // создаем соеденение 
    $stmt = mysqli_prepare($conn, "DELETE FROM OrdersProducts WHERE OrderID=?;");  // пишем SQL Query 
    mysqli_stmt_bind_param($stmt, "i", $orderID); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success
    mysqli_stmt_close($stmt); // close statement 
  return $success;
}

function deleteOrder($orderID)
{
    global $conn; // создаем соеденение 
  $stmt = mysqli_prepare($conn, "DELETE FROM OrdersProducts WHERE OrderID=?;");  // пишем SQL Query 
  mysqli_stmt_bind_param($stmt, "i", $orderID); // giving parametrs to data beiing inputing 
    $success = mysqli_stmt_execute($stmt);  //dealare success

    $stmt = mysqli_prepare($conn, "DELETE FROM Orders WHERE OrderID=?;");  // пишем SQL Query 
    mysqli_stmt_bind_param($stmt, "i", $orderID); // giving parametrs to data beiing inputing 
    $success = $success && mysqli_stmt_execute($stmt);  //dealare success

  return $success;
}

  

?>