<?php

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

include "pages/view-products-page.php"
?>