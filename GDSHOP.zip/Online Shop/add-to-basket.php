<?php 
if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";
//assume that we will fail
$response = "false";
// check that we have productid
if(!empty($_GET['productid']))

{
// check that the basket exists in the session
    if(empty($_SESSION['basket']))
    {
// if if does not create it
        $_SESSION['basket'] = [];
    }
    // add the product id to the basket array in the session
    $_SESSION['basket'] [] = $_GET['productid'];

    // store that we have succeded
    $response = "true";
}
// echo whether we have succeded or failed 
echo $response;

?>