<?php
require "includes/authorisation-admin.php";

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";

require_once "models/Categories.php";

if (!empty($_POST["CategoryID"]) &&
    !empty($_POST["Category"]))
{

    updateCategory($_POST["CategoryID"], $_POST["Category"]);

    redirect("edit-categories.php", false);
}

?>