<?php 

if (session_status() == PHP_SESSION_NONE) {session_start();}
require_once "includes/utility-functions.php";
require_once "models/Users.php";

if(!empty($_POST['EmailAddress']) && 
!empty($_POST['MobileNumber']) &&
!empty($_POST['Titel']) &&
!empty($_POST['Firstname']) &&
!empty($_POST['Surname']) &&
!empty($_POST['ApartmentNumber']) &&
!empty($_POST['Street']) &&
!empty($_POST['City']) &&
!empty($_POST['Region']) &&
!empty($_POST['Postcode']) &&
!empty($_POST['Country']) &&
!empty($_POST['RegistrationPassword']) &&
!empty($_POST['ConfirmRegistrationPassword']) &&
strlen($_POST['RegistrationPassword']) >=8 &&
$_POST['RegistrationPassword'] == $_POST['ConfirmRegistrationPassword'])
{


    if(!userExists($_POST['EmailAddress'])) 
    {

$hashedPassword = password_hash($_POST['RegistrationPassword'], PASSWORD_DEFAULT);
$role = fristUser() ? "admin":"user";

$success = insertUser($_POST['EmailAddress'], $_POST['MobileNumber'], $_POST['Titel'], $_POST['Firstname'], $_POST['Surname'], $_POST['ApartmentNumber'],
 $_POST['Street'], $_POST['City'], $_POST['Region'], $_POST['Postcode'], $_POST['Country'], $hashedPassword, $role);
    

if($success)
{
//log the user in and redirect to the succes page
login($_POST['EmailAddress'], $_POST['RegistrationPassword']);
redirect("index.php", false);
exit();

}
else
{

    echo "Server error";
    redirect("index.php", true);
    exit(); 

}

    }

else
{
echo "User already exits";
redirect("index.php", true);
exit();

}
}

else{

    echo "invalid data submited";
redirect("index.php", false);
exit();

}
?>